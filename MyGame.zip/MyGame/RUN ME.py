#project description:
# this game was created in pycharm. I decided on this topic because when I was exploring Python on my own I saw a couple videos of
# people creating their own custom games and I insantly wanted to try it, so this was a perfect excuse to spend many hours and several
#all nighters to test myself and learn something new. This project was especially challenging because I knew I had to come up
#complete several goals established by the guidelines of the project while also attempting to create a playable game.
#I have created a game that has several interesting features:
    #1. after running the module, a screen will appear with 3 entities: one player(the alien) and two enemies (the robot and octopus)
    #2. the player is controlled by the arrow keys. whenever the keys are pressed the ufo will move in that direction. The unique portion
        #of the movement features is that when the players course is changed, it randomly alters the movement direction and speed of the enemies.
    #3. the space bar fires a "laser" and upon contacting the enemies a point will be added and the mobs will be reset to a
        #random position. upon reaching 10 points, the game will end and you have won. If thirty seconds passes and you have still
        #not scored 10 points, the game will end and you will lose.
    #4. upon reaching a certain amount of points, the background screen will change.
        #first blue, then flashing dim colors, and at 9 points it REALLY flashes.

#sidebar- I'm not sure why the hit system works better with the robot than with the octopus, it is practically the same code
import mymodule
###********IF YOU DON'T WANT FLASHING LIGHTS PLEASE ALTER CODE LINE 95 on RGB area.**************
