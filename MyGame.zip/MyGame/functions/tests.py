import pytest
from mymodule.py import colorchange
from mymodule.py import hit

def test_colorchange():

    assert callable(colorchange)
    assert isinstance(colorchange(str))
    assert colorchange(counter = 3) == "I'm blue!"
def test_hit():
    assert callable(hit)
    assert isinstance(hit, int)