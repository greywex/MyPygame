#altered to be more easily testable, still tests functionality (counter defines color change)
def colorchange():
    counter = 2
    if counter <= 4:
        print("I'm blue!")
    if counter >= 5 and counter < 9:
        print("I'm changing colors!")
    if counter == 9:
        print("I'm REALLY changing colors!")

#tests if output is an integer when using an input, if output is int that is lower than 90 the function
#will return True and hit will register
def hit(enemy1X, ememy1Y, laserX, laserY):
    distance = math.sqrt((math.pow(enemy1X - laserX, 2)) + (math.pow(enemy1Y - laserY, 2)))
    if distance < 90:
        return True